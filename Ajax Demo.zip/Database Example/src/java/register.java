import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class register extends HttpServlet {

    Connection con;
    PreparedStatement ps;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        RequestDispatcher rd = request.getRequestDispatcher("status.jsp");
        PrintWriter pw = response.getWriter();
        
        int sid = Integer.parseInt(request.getParameter("sid"));
        String name = request.getParameter("name");
        String addr = request.getParameter("address");
        con = SQL.getConnection();
        String query = "insert into Student(sid,name,address) values(?,?,?)";
        try{
        
            ps = con.prepareStatement(query);
            ps.setInt(1, sid);
            ps.setString(2, name);
            ps.setString(3,addr);
            
            int i = ps.executeUpdate();
            if(i>0)
            {
                pw.println("Record inserted successfully");                
                rd.include(request, response);
            }
            else
            {
                pw.println("Insertion failed! try again");                
                rd.include(request, response);
            }
        }catch(SQLException sqe)
        {
            System.err.println(sqe);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         String check = req.getParameter("name");
         
        if(check.contains("@") || check.contains("#"))
        {
            System.out.println(check);
            resp.getWriter().write("<html><h3 style='color:red'>Special characters not allowed</html>");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
